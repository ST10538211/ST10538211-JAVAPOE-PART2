package prog5121;

import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {

    @Test
    public void testCheckUserNameCorrect() {
        Login login = new Login();
        assertTrue(login.checkUserName("kyl_1"));
    }

    @Test
    public void testCheckUserNameIncorrect() {
        Login login = new Login();
        assertFalse(login.checkUserName("kyle!!!!!!!"));
    }

    @Test
    public void testPasswordSuccess() {
        Login login = new Login();
        assertTrue(login.checkPasswordComplexity("Ch33se@sP"));
    }

    @Test
    public void testPasswordFailure() {
        Login login = new Login();
        assertFalse(login.checkPasswordComplexity("password"));
    }

    @Test
    public void testCheckCellPhoneNumberSuccess() {
        Login login = new Login();
        assertTrue(login.checkCellPhoneNumber("+27831234567"));
    }

    @Test
    public void testCheckCellPhoneNumberFailure() {
        Login login = new Login();
        assertFalse(login.checkCellPhoneNumber("0831234567"));
    }

    @Test
    public void testRegisterUserSuccess() {
        Login login = new Login();
        login.setUsername("kyl_1");
        login.setPassword("Ch33se@sP");
        login.setCellNumber("+27831234567");

        String expected = "User registered successfully.";
        assertEquals(expected, login.registerUser());
    }

    @Test
    public void testLoginUserSuccess() {
        Login login = new Login();
        login.setUsername("kyl_1");
        login.setPassword("Ch33se@sP");

        assertTrue(login.loginUser("kyl_1", "Ch33se@sP"));
    }

    @Test
    public void testLoginUserFailure() {
        Login login = new Login();
        login.setUsername("kyl_1");
        login.setPassword("Ch33se@sP");

        assertFalse(login.loginUser("kyl_1", "wrongPassword"));
    }

    @Test
    public void testReturnLoginStatusSuccess() {
        Login login = new Login();
        login.setFirstName("Kyle");
        login.setLastName("llai");

        String expected = "Welcome Kyle, llai it is great to see you again.";
        assertEquals(expected, login.returnLoginStatus(true));
    }

    @Test
    public void testReturnLoginStatusFailure() {
        Login login = new Login();

        String expected = "Username or password incorrect, please try again.";
        assertEquals(expected, login.returnLoginStatus(false));
    }
}