package prog5121;

import org.junit.Test;
import static org.junit.Assert.*;

public class ChatManagerTest {

    @Test
    public void testSendMessageSuccess() {
        ChatManager manager = new ChatManager();
        boolean result = manager.sendMessage("+27831234567", "Hello from Part 2!");
        assertTrue(result);
        assertEquals(1, manager.getMessageStore().size());
        assertTrue(manager.getMessageStore().get(0).isSent());
    }

    @Test
    public void testReceiveMessageSuccess() {
        ChatManager manager = new ChatManager();
        Message msg = new Message("+27831234567", "Test payload");
        msg.setSent(true);

        boolean result = manager.receiveMessage(msg);
        assertTrue(result);
        assertTrue(msg.isReceived());
    }

    @Test
    public void testReadMessageSuccess() {
        ChatManager manager = new ChatManager();
        Message msg = new Message("+27831234567", "Test payload");
        msg.setSent(true);
        msg.setReceived(true);

        boolean result = manager.readMessage(msg);
        assertTrue(result);
        assertTrue(msg.isRead());
    }

    @Test
    public void testReadMessageFailureWithoutReceive() {
        ChatManager manager = new ChatManager();
        Message msg = new Message("+27831234567", "Test payload");
        msg.setSent(true);
        msg.setReceived(false);

        boolean result = manager.readMessage(msg);
        assertFalse(result);
        assertFalse(msg.isRead());
    }
}